# Food Image Recognition & Ingredient Identification — Streamlit

## Run locally (Windows / VS Code)
1. Extract this ZIP into a folder.
2. Open the folder in VS Code.
3. Open Terminal and run:
   ```bat
   python -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   streamlit run app.py
   ```
4. Open the local URL shown by Streamlit, usually http://localhost:8501.

## Included files
- `app.py` — Streamlit application
- `food_classifier_finetuned.pth` — fine-tuned MobileNetV2 weights
- `ingredient_lstm.pth` — retained model file (the experimental sequence display is hidden to avoid confusing output)
- `food_classes.json` — food category labels
- `ingredient_mapping.json` — curated typical ingredient lists
- `ingredient_images/` — includes individual ingredient photos for biryani
- `requirements.txt` — Python dependencies

## Biryani ingredient display
The app now shows a curated biryani ingredient list with individual local photos included in `ingredient_images/`. The list is typical for biryani and can vary by recipe. The model predicts the dish category; it does not independently verify each ingredient in the uploaded food photo.

Ingredient photos included for biryani: basmati rice, onion, tomato, garlic, ginger, green chilli, mint leaves, coriander leaves, yogurt, ghee, biryani spices, cashew, fried onions, lemon, and salt.

Other dish categories still use the ingredient mappings, but only the biryani ingredient photos are bundled in this update. You can add photos for other categories using matching filenames.
